package com.michael.polymorphism;

public class Wolf extends Animal{
	
	@Override
	public void move() {
		System.out.println("Wolf is runnung");
	}
}
