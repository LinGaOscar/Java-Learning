package com.michael.homework.inheritance;

/**
 * �D�ް����O �~�� ��¾�����O
 * @author michaelchai
 *
 */
public class ChargeDefault extends EmployeeDefault{
	private double lunchAllowance;
	private double duties;
	private double transportAllowance;
	
	public double getLunchAllowance() {
		return lunchAllowance;
	}

	public void setLunchAllowance(double lunchAllowance) {
		this.lunchAllowance = lunchAllowance;
	}

	public double getDuties() {
		return duties;
	}

	public void setDuties(double duties) {
		this.duties = duties;
	}

	public double getTransportAllowance() {
		return transportAllowance;
	}

	public void setTransportAllowance(double transportAllowance) {
		this.transportAllowance = transportAllowance;
	}

	public ChargeDefault() {
		ChargeDefaultInit();
	}
	
	public ChargeDefault(String name, String sex, String hiredate, String tel, String address, double salary,
			double overtimeHour) {
		super(name, sex, hiredate, tel, address, salary, overtimeHour);
		ChargeDefaultInit();
	}
	
	/**
	 * ���o�D�޷����~��
	 */
	public double getMonthMoney() {
		double tempMonthMoney = super.getMonthMoney() + lunchAllowance + duties + transportAllowance;
		System.out.println("�D�޷����~�� :" + tempMonthMoney );
		return tempMonthMoney;
	}
	
	public void ChargeDefaultInit() {
		//���\�z�K��1800���A��q�z�K��2000��
        lunchAllowance = 1800;
        transportAllowance = 2000;
        duties = 0;
	}
	
}
