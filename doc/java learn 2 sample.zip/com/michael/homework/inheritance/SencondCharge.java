package com.michael.homework.inheritance;

public class SencondCharge extends ChargeDefault{

	public SencondCharge() {
		super();
		SencondChargeInit();
	}

	public SencondCharge(String name, String sex, String hiredate, String tel, String address, double salary,
			double overtimeHour) {
		super(name, sex, hiredate, tel, address, salary, overtimeHour);
		//setOvertimeHour(overtimeHour);//�]�w�[�Z�ɼ�
		SencondChargeInit();
	}
	
	public void SencondChargeInit() {
	  //¾�ȥ[���G�ťD�ެ�3000���C
		setDuties(3000);
	}
}
