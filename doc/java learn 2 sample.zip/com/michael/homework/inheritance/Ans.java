package com.michael.homework.inheritance;

public class Ans {

	public static void main(String[] args) {
		
		employee("�@��¾��1","Tom", "M", "92/01/01", "0944333222", "�x�_��", 20000, 0);
		employee("�@��¾��2","Jane", "F", "91/07/01", "0908321223", "�s�_��", 20000, 20);
		
		sencondCharge("�G�ťD��1","Sam", "M", "90/12/01", "0908112334", "�x����", 30000, 0);
		sencondCharge("�G�ťD��2","Marry", "F", "89/5/01", "0955111222", "�s�˥�", 30000, 30);
		
		firstCharge("�@�ťD��1","Amy", "F", "88/09/01", "0955444333", "�x�n��", 45000, 0);
		firstCharge("�@�ťD��2","John", "M", "88/07/01", "0915323123", "������", 45000, 15);
		
		
	}
	
	public static void employee(String jobTitle, String name,String sex, String hiredate, String tel, String address, double salary,double overtimeHour) {
		System.out.println(jobTitle);
		Employee employee = new Employee(name, sex, hiredate, tel, address, salary, overtimeHour);
		employee.getBaseData();
		employee.getMonthMoney();
		System.out.println("====================================");
	}
	
	public static void sencondCharge(String jobTitle, String name,String sex,  String hiredate, String tel, String address, double salary,double overtimeHour) {
		System.out.println(jobTitle);
		SencondCharge sencondCharge = new SencondCharge(name, sex, hiredate, tel, address, salary, overtimeHour);
		sencondCharge.getBaseData();
		sencondCharge.getMonthMoney();
		System.out.println("====================================");
	}
	
	public static void firstCharge(String jobTitle, String name, String sex, String hiredate, String tel, String address, double salary,double overtimeHour) {
		System.out.println(jobTitle);
		FirstCharge firstCharge = new FirstCharge(name, sex, hiredate, tel, address, salary, overtimeHour);
		firstCharge.getBaseData();
		firstCharge.getMonthMoney();
		System.out.println("====================================");
	}

}
