package com.michael.homework.inheritance;

/**
 * ¾�������O
 * 
 * @author michaelchai
 *
 */
public class EmployeeDefault {
	// ���q�C�ӭ��u�Ҧ��m�W�B�ʧO�B��¾��B�q�ܩM���}���򥻸�ơC
	private String name;
	private String sex;
	private String hiredate;
	private String tel;
	private String address;
	private double salary;
	private double overtimeHour;

	public EmployeeDefault() {

	}

	public EmployeeDefault(String name, String sex, String hiredate, String tel, String address, double salary,
			double overtimeHour) {
		this.name = name;
		this.sex = sex;
		this.hiredate = hiredate;
		this.tel = tel;
		this.address = address;
		this.salary = salary;
		this.overtimeHour = overtimeHour;
	}
	
	
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getHiredate() {
		return hiredate;
	}

	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public double getOvertimeHour() {
		return overtimeHour;
	}

	public void setOvertimeHour(double overtimeHour) {
		this.overtimeHour = overtimeHour;
	}

	/**
	 * ���o�[�Z�O
	 * 
	 * @return
	 */
	public double getOvertimeMoney() {
		
		double money = (salary / 240) * 1.5 * overtimeHour;
		return money;
	}

	/**
	 * �L�X�򥻸��
	 */
	public void getBaseData() {
		System.out.println("�m�W : " + name + ", �ʧO : " + sex + ", ��Ȥ�: " + hiredate + ", �q��:" + tel);
	}

	/**
	 * ���o�����~��(�t�[�Z�O)
	 * @return
	 */
	public double getMonthMoney() {
		System.out.println("�[�Z�O : " + getOvertimeMoney());
		return salary + getOvertimeMoney();
	}
}
