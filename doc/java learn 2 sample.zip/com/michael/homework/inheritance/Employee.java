package com.michael.homework.inheritance;

/**
 * �@��¾��
 * @author michaelchai
 *
 */
public class Employee extends EmployeeDefault{
	
	public Employee() {
		
	}

	public Employee(String name, String sex, String hiredate, String tel, String address, double salary,
			double overtimeHour) {
		super(name, sex, hiredate, tel, address, salary, overtimeHour);
		
	}
	
	
	public double getMonthMoney() {
		double tempMonthMoney = super.getMonthMoney();
		System.out.println("¾�������~�� :" + tempMonthMoney );
		return tempMonthMoney;
	}
}
