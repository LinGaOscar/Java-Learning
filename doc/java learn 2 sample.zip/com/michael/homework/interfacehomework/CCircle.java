package com.michael.homework.interfacehomework;
import java.lang.Math;

public class CCircle implements CShape {

	public double radius;

	public CCircle(double radius) {
		this.radius = radius;
	}

	@Override
	public void showArea() {
		System.out.println("��έ��n��" + PI * radius * radius);
	}

	@Override
	public void showVolume() {
		System.out.println("�����n��" + (4/3) * PI * Math.pow(radius,3) );
	}

}
