package com.michael.homework.interfacehomework;

public interface CShape {
	final double PI = 3.14;
	public void showArea();
	public void showVolume();
}
