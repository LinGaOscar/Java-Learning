package com.michael.homework.interfacehomework;

public class CRectangle implements CShape {

	public int length;
	public int width;
	public int height;

	public CRectangle(int length, int width, int height) {
		this.length = length;
		this.width = width;
		this.height = height;
	}

	@Override
	public void showArea() {
		System.out.println("�x�έ��n=" + width * height);
	}

	@Override
	public void showVolume() {
		System.out.println("�x����n=" + length * width * height);
		
	}
	
	

}
