package com.michael.homework.interfacehomework;

public class InterfaceDemo {

	public static void main(String[] args) {
		CShape cshape01 = new CCircle(4);
		cshape01.showArea();
		cshape01.showVolume();
		
		CShape cshape02 = new CRectangle(3, 6, 5);
		cshape02.showArea();
		cshape02.showVolume();
	}

}
