package com.michael.homework.encapsulation;

public class AccountDemo {

	public static void main(String[] args) {
		
		Account account = new Account();
        System.out.println("�b��: " + account.getAccountNumber()); 
        System.out.println("�l�B: " + account.getBalance()); 
        System.out.println("========================== "); 
        
        account = new Account("123-4567", 100.0);
        System.out.println("�b��: " + account.getAccountNumber()); 
        System.out.println("�l�B: " + account.getBalance());
        account.deposit(1000.0);
        System.out.println("�s 1000 �l�B: " + account.getBalance());
        account.withdraw(200.0);
        System.out.println("�� 200 �l�B: " + account.getBalance());
	}

}
