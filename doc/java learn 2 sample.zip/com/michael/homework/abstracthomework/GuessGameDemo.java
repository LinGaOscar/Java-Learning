package com.michael.homework.abstracthomework;

public class GuessGameDemo {

	public static void main(String[] args) {
		AbstractGuessGame guessGame = new TextModeGame();
		guessGame.setNumber(45);
		guessGame.start();

	}

}
