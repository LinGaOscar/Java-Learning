package com.michael.interfacesample;

public class Boss {

	public static void main(String[] args) {
		
		//interfaceSample();

		polymorphsim();
	}
	
	public static void polymorphsim() {
		
		EmployeeTwo employeeTwo = new EmployeeTwo();
		employeeTwo.name = "Oscar";
		System.out.println(employeeTwo.name);
		skill(employeeTwo);
		
		EmployeeThree employeeThree = new EmployeeThree();
		employeeThree.name = "Eason";
		System.out.println(employeeThree.name);
		skill(employeeThree);
		
		EmployeeFour employeeFour =  new EmployeeFour();
		employeeFour.name="Lily";
		System.out.println(employeeFour.name);
		//kindSkill.skill(employeeFour);//�S����@�Ҧ�����k
		
	}
	
	public static void skill(Designer designer) {
		
		System.out.println(designer.usePhotoshop());
		System.out.println(designer.useIllustrator());
	}
	

	public static void interfaceSample() {
		EmployeeOne employeeOne = new EmployeeOne();
		employeeOne.name = "Michael";
		String ps = employeeOne.photoshop();
		String ai = employeeOne.illustrator();
		
		System.out.println(employeeOne.name);
		System.out.println(ps);
		System.out.println(ai);
		
		EmployeeTwo employeeTwo = new EmployeeTwo();
		employeeTwo.name ="Oscar";
		ps = employeeTwo.usePhotoshop();
		ai = employeeTwo.useIllustrator();
		
		System.out.println(employeeTwo.name);
		System.out.println(ps);
		System.out.println(ai);
		
		EmployeeThree employeeThree = new EmployeeThree();
		employeeThree.name = "Eason";
		ps = employeeThree.usePhotoshop();
		ai = employeeThree.useIllustrator();
		
		System.out.println(employeeThree.name);
		System.out.println(ps);
		System.out.println(ai);
		
		EmployeeFour employeeFour =  new EmployeeFour();
		employeeFour.name="Lily";
		ps = employeeFour.usePhotoshop();
		System.out.println(employeeFour.name);
		System.out.println(ps);
	}
}
