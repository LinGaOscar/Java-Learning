package com.michael.interfacesample;

public class Employee {
	public String name;
}
