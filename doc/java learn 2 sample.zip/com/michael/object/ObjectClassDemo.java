package com.michael.object;

public class ObjectClassDemo {

	public static void main(String[] args) {

		//objectSample();

		// AutoBox
		//objectSample1();
		
		//�����ƭȬ۵��M����۵������P
		//objectSample3(); 

		// object and class ���������Y
		objectSample4();
	}

	public static void objectSample() {
		int data1 = 10;
		int data2 = 20;

		// �ϥ�Integer(����)�ӥ]��int��� => ���Ѥ@�ǳB�zint��ƪ���k
		Integer data1Wrapper = new Integer(data1);
		Integer data2Wrapper = new Integer(data2);

		// �������H3
		System.out.println(data1 / 3);

		// �ରdouble�ȦA���H3
		System.out.println(data1Wrapper.doubleValue() / 3);

		// �i���ӭȪ����
		System.out.println(data1Wrapper.compareTo(data2Wrapper));

	}

	public static void objectSample1() {
		Integer data1 = 10;
		Integer data2 = 20;

		// �ରdouble�ȦA���H3
		System.out.println(data1.doubleValue() / 3);

		// �i���ӭȪ����
		System.out.println(data1.compareTo(data2));
	}

	public static void objectSample3() {
		Integer i1 = 100;
		Integer i2 = 100;
		Integer i3 = 200;
		Integer i4 = 200;
		Integer data1Wrapper = new Integer(100);
		Integer data2Wrapper = new Integer(100);

		if (i1 == i2) {
			System.out.println("i1 == i2");
		} else {
			System.out.println("i1 != i2");
		}
		
		if(i1.equals(i2)) {
			System.out.println("i1 == i2");
		}else {
			System.out.println("i1 != i2");
		}

	}

	public static void objectSample4() {
		// �إ߷s���� �æb�إ߮ɴN�ᤩ���ݩʪ��ܼƭ�
		ClassObject carOne = new ClassObject("BNW", "X3");

		System.out.println("car brand: " + carOne.getBrand() + "\ncar name: " + carOne.getCarModel());
		System.out.println("=========================================================");

		ClassObject carTwo = new ClassObject(); // ����

		carTwo.setBrand("TOYOTA");
		carTwo.setCarModel("ALTIS GR SPORT");
		carTwo.setSpeed(0.0);
		System.out.println("car org speed: " + carTwo.getSpeed());
		
		carTwo.setSpeed(carTwo.addSpeed(carTwo.getSpeed(), 1.2));
		carTwo.setSpeed(carTwo.addSpeed(carTwo.getSpeed(), 1.2));
		System.out.println("car add speed: " + carTwo.getSpeed());
		
		carTwo.setSpeed(carTwo.subSpeed(carTwo.getSpeed(), 1.2));
		System.out.println("car sub speed: " + carTwo.getSpeed());

		String brand = carTwo.getBrand();

		System.out.println("car brand: " + carTwo.getBrand() + "\ncar name: " + carTwo.getCarModel());

		System.out.println("brand length = " + brand.length());
	}

}
