package com.michael.object;

public class ClassObject {
	
	//Constructor(�غc�l) �S���g�ɷ|�۰ʲ��ͤ�������ƪ��غc�l
	public ClassObject() {
		System.out.println("Constructor!!");
	}
	
	public ClassObject(String brand, String carModel) {
		this.brand = brand;
		this.carModel = carModel;
	}
	
	//��ƪ��Φ�(�ݩ�, Field) Class Variable(���O�ܼ�)
	public String brand;
	public String carModel;
	public double speed;
	
	//���ƪ��ާ@(��k, Method) Class Method(���O��k)
	public String getBrand() {
		return brand;
	}
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public String getCarModel() {
		return carModel;
	}

	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	
	public double getSpeed() {
		return speed;
	}

	public void setSpeed(double speed) {
		this.speed = speed;
	}
	
	public double addSpeed(double speed,double add) {
		return speed == 0.0 ? 1 : speed * add;
	}
	
	public double subSpeed(double speed,double add) {
		return speed / add;
	}

}
