package com.michael.encapsulation;

public class Before {
	
	public static void main(String[] args) {

		String name = "GLE-SUV";// ���
		double speed = 0.0;

		speed = speed + 1; //�欰
		printlnInfo(name, speed);

		speed = speed * 1.2;
		speed = speed * 1.2;
		printlnInfo(name, speed);

		speed = speed * 0.8;
		speed = speed * 0.8;
		printlnInfo(name, speed);

		Car car1 = new Car();
		car1.setName("GLE-SUV"); // private String name
		car1.brand = "���h"; // public String brand
		car1.power = 6.5; // protected double power;
		car1.kg = 5000.0; // double kg;
		printlnAccessModifyInfo(car1.toString(), car1.brand, car1.power, car1.kg);

	}
	
	public static void printlnInfo(String name, double speed) {
		System.out.println("[Car name=" + name + ", speed=" + speed + "]");
	}
	
	public static void printlnAccessModifyInfo(String toString,String brand, double power, double kg) {
		System.out.println(toString + " brand = " + brand + " power = " + power + " kg = " + kg);
	}

}
