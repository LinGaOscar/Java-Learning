package com.michael.encapsulation;

public class Car {

	private String name;
	private double speed;
	public String brand;
	protected double power;
	double kg;

	@Override
	public String toString() {
		return "Car [name=" + name + ", speed=" + speed + ", brand = " + brand + ", power = "+ power + ", kg = "+ kg + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void upSpeed() { // �[�t
		speed = speed < 1 ? 1 : speed * 1.2;
	}

	public void downSpeed() {// ��t
		speed = speed < 1 ? 0 : speed * 0.8;
	}
	
	
	
}
