package com.michael.encapsulation;

public class GoCar {

	public static void main(String[] args) {

		Car car1 = new Car();
		car1.setName("GLE-SUV"); // private String name
		car1.brand = "���h"; // public String brand
		car1.power = 6.5; // protected double power;
		car1.kg = 5000.0; // double kg;
		car1.upSpeed();
		System.out.println(car1.toString()); //TODO �s���׹��l sample �P���O
		System.out.println(" brand = " + car1.brand + " power = " + car1.power + " kg = " + car1.kg);//TODO �s���׹��l sample �P package���l���O
		car1.upSpeed();
		car1.upSpeed();
		System.out.println(car1.toString());
		car1.downSpeed();
		car1.downSpeed();
		System.out.println(car1.toString());
	}

}
