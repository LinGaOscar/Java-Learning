package com.michael.abstractSample;

public class Circle {

	public static void main(String[] args) {
		ConcreteCircle concreateCircle = new ConcreteCircle();
		concreateCircle.render();
		
		HollowCircle hollowCircle = new HollowCircle(); 
		hollowCircle.render();
		
		
		//AbstractCircle AbstractCircle = new AbstractCircle();//���� new ���@�ӷs����
		
		
		
		renderCircle(new AbstractConcreteCircle(3.0987));
		renderCircle(new AbstractHollowCircle(6.01155));
		
		
	}
	
	public static void renderCircle(AbstractCircle circle ) {
		circle.render();
	}

}
