package com.michael.abstractSample;

public class AbstractHollowCircle extends AbstractCircle{

	public AbstractHollowCircle() {
		
	}
	
	public AbstractHollowCircle(double radius) {
		this.radius = radius;
	}
	
	public void render() {
		System.out.printf("�e�@�ӥb�| %f ���Ť߶�\n", getRadius());
	}
}
