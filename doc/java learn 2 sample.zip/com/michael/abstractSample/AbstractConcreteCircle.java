package com.michael.abstractSample;

public class AbstractConcreteCircle extends AbstractCircle{
	
	public AbstractConcreteCircle() {
		
	}

	public AbstractConcreteCircle(double radius) {
	        this.radius = radius;
	}

	public void render() {
		System.out.printf("�e�@�ӥb�| %f ����߶�\n", getRadius());
	}
}
