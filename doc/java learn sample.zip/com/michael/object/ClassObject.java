package com.michael.object;

import com.michael.encapsulation.Car;

public class ClassObject {
	
	//Constructor(�غc�l) �S���g�ɷ|�۰ʲ��ͤ�������ƪ��غc�l
	public ClassObject() {
		System.out.println("Constructor!!");
	}
	
	public ClassObject(String brand, String carModel) {
		this.brand = brand;
		this.carModel = carModel;
	}
	
	//��ƪ��Φ�(�ݩ�, Field) Class Variable(���O�ܼ�)
	public String brand;
	public String carModel;
	
	//���ƪ��ާ@(��k, Method) Class Method(���O��k)
	public String getBrand() {
		return brand;
	}
	
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public String getCarModel() {
		return carModel;
	}

	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}

	public static void main(String[] args) {
		
		//�إ߷s���� �æb�إ߮ɴN�ᤩ���ݩʪ��ܼƭ�
		ClassObject carOne = new ClassObject("BNW","X3"); 
		
		//carOne.setBrand("BNW");
		//carOne.setCarModel("X3");
       
        
        System.out.println("car brand: " + carOne.getBrand() + "\ncar name: " + carOne.getCarModel());
        System.out.println("=========================================================");
        
        ClassObject carTwo = new ClassObject(); //����
		
        carTwo.setBrand("TOYOTA");
        carTwo.setCarModel("ALTIS GR SPORT");
        
        
        System.out.println("car brand: " + carTwo.getBrand() + "\ncar name: " + carTwo.getCarModel());
        
	}

	

	

}
