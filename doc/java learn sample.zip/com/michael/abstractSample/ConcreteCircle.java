package com.michael.abstractSample;

public class ConcreteCircle {
	private double radius;

	public void setRedius(int radius) {
		this.radius = radius;
	}

	public double getRadius() {
		return radius;
	}

	public void render() {
		System.out.printf("�e�@�ӥb�| %f ����߶�\n", getRadius());
	}
}
