package com.michael.polymorphism;

public class Fish extends Animal{
	
	public void move() {
		System.out.println("Fish is swimming");
	}
}
