package com.michael.polymorphism;
import com.michael.inheritance.Animal;

public class Cow extends Animal{
	
	public void sleep() {
		System.out.println("Cow is sleep");
	}
	
	public void getInfo() {
		//TODO �s���׹��l sample ���P package ���l���O
		String name = super.name; //public
		int age = super.age; //protected
		//String size = super.size;//default
		//String color = super.color; //private
		System.out.println("cow name = "+name+", age = "+age); 
	}
	
}
