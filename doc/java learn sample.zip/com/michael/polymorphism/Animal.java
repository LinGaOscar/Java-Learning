package com.michael.polymorphism;

public class Animal {
	public void move() {
		System.out.println("Animal is running");
	}
}
