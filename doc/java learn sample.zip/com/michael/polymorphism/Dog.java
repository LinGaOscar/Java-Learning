package com.michael.polymorphism;

public class Dog extends Animal{
	
	public void bark() {
		System.out.println("Dog is bark");
	}

	//TODO �мg
	public void move() {
		System.out.println("Dog is running");
	}
}
