package com.michael.polymorphism;

public class GoAnimal {

	public static void main(String[] args) {
		
		polymorphismSample();
		
		//polymorphismSample2();
		
		//accessModifierSample();
		
	}
	
	public static void polymorphismSample() {
		 //�S�h�������p
		 Animal ani =new Animal();
	     Animal dog =new Dog();
	     Animal bird =new Bird();
	     Animal fish =new Fish();

	     ani.move();
	     dog.move();
	     bird.move();
	     fish.move();
	     
	     System.out.println("===================================");
	     
	     //�h�������p
	     Animal ani1 =new Animal();
	     Dog dog1 =new Dog();
	     Bird bird1 =new Bird();
	     Fish fish1 =new Fish();
	     
	    
	     
	     moveAnimal(ani1);
	     moveAnimal(dog1);//�����૬ Implicit Casting ����U��
	     moveAnimal((Animal)dog1);
	     moveAnimal(bird1);
	     moveAnimal(fish1);
	     
	     //Dog dog2 = (Dog) new Animal();
	     //moveAnimal(dog2);//�૬���� �����O�����ন�l���O
	}
	
	//�]�p�@�Ӥ�k�ΨөI�s Animal�BDog�BBird�BFish������move()��k
	public static void moveAnimal(Animal ani) {
		ani.move();
	}
	
	public static void polymorphismSample2() {
		Animal animal1 = new Animal();
		animal1.move();
		
		animal1 = new Wolf();
		animal1.move();
		
		animal1 = new Dog();
		animal1.move();
		((Dog) animal1).bark();
		
		//instanceof �P�_�O�_���P����
		System.out.println(animal1 instanceof Wolf);
		System.out.println(animal1 instanceof Dog);
		System.out.println(animal1 instanceof Animal);
	}
	
	//TODO �s���׹��l sample ���P package
	public static void accessModifierSample() {
		Cow cow = new Cow();
		//�D�l class
		String name = cow.name; //public
		//int age = cow.age; //protected
		//String size = cow.size; //default
		String coloer = cow.getColor(); //private
		
		//�l class
		cow.getInfo();
	}

}
