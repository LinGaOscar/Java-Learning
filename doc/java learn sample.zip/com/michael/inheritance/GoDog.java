package com.michael.inheritance;

public class GoDog {

	public static void main(String[] args) {
		Animal animal = new Animal(); //�����O
		animal.run();
		System.out.println();
		
		Dog dog1 = new Dog();//�l���O
		dog1.bark();
		dog1.run();
		System.out.println();
		
		//TODO �s���׹��l sample �Ppackage���l���O
		String name = dog1.name;
		int age = dog1.age;
		String size = dog1.size;
		//String color = dog1.color;

		AkitaDog akitaDog = new AkitaDog();
		String dogName = akitaDog.name; //Animal
		String dogBreeds = akitaDog.breeds; //Dog
		akitaDog.info();
		akitaDog.run();
		animal.run();
		System.out.println("dogName ="+dogName + " ,dogBreeds ="+dogBreeds);
	}

}
