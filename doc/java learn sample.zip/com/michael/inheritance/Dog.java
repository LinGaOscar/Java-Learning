package com.michael.inheritance;

public class Dog extends Animal{
	public String breeds;
	
	public void bark() {
		System.out.println("Dog is bark");
	}
}
