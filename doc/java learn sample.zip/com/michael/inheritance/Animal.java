package com.michael.inheritance;

public class Animal {
	public String name = "xxx";
	protected int age = 2;
	String size = "middle";
	private String color ;
	
	public void run() {
		System.out.println("Animal is running");
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
}
