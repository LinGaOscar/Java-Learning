package com.michael.homework;

public abstract class AbstractGuessGame {
	private int number;

	public void setNumber(int number) {
		this.number = number;
	}
	
	public void start() {
		showMsg("wellcom!!");
		int guess = 0;
		do {
			guess = getUserInput();
			if(guess > number) {
				showMsg("input number is big then guess!!");
			}else if (guess < number){
				showMsg("input number is small then guess!!");
			}else {
				showMsg("bingo!!");
			}
		}while(guess != number);
	}
	
	protected abstract void showMsg(String msg);
	protected abstract int getUserInput(); 
}
