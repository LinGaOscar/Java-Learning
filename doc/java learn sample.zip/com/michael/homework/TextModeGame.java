package com.michael.homework;

import java.util.Scanner;

public class TextModeGame extends AbstractGuessGame{

	private Scanner scanner;

    public TextModeGame() {
        scanner = new Scanner(System.in);//�b console ��J��r
    }
    
    protected void showMsg(String msg) { //�b��ܤ�r���e��[ * ���Ϲj
        for(int i = 0; i < msg.length()*2; i++) {
            System.out.print("*");
        }
        System.out.println("\n"+ msg);
        for(int i = 0; i < msg.length()*2; i++) {
            System.out.print("*");
        }
    }

    protected int getUserInput() {//���o console ��J��r
        System.out.print("\n��J�Ʀr�G");
        return scanner.nextInt();
    }

}
