package com.michael.homework;

public class Pyramid {
	
	
	public static void main(String[] args) {
		
		//�C�L
		//printLeftPyramid(8);
		//System.out.println("=======================================");
		//printPyramid(3,2); //line 
		printLogic(3);
	}
	
	public static void printLeftPyramid(int turns) {
		for (int i=0 ;i< turns ;i++) {
			for (int j=0;j < i+1;j++) {
				System.out.print("*");
			}
			System.out.println("");
		}
		for (int k=0; k < turns ; k++) {
			for (int m=0 ;m < turns-k-1;m++) {
				System.out.print("*");
			}
			System.out.println("");
		}
	}
	
	public static void printPyramid(int line, int multiple) {
		//���
		for (int i=0; i < line; i++) {
			// �L�X�ť� => ���-1 
			for (int j=0;j < line-i;j++) {
				
				System.out.print(" ");
			}
			
			// �L�X�P�P => �⭿���-1
            for (int k=0;k < multiple *i-1; k++) {
				
				System.out.print("*");
			}
			
			System.out.println("");
		}
	}
	
	//�i���� (�����)
	private static void printLogic(int count) {
		try {
			count = Math.max(1, ((count % 2 == 0) ? count - 1 : count));
			int middle = (count + 1) / 2;
			for (int y = 0; y < middle; y++) {
				int z = (count - (1 + (2 * y))) / 2;// star
				for (int x = 0; x < count; x++) {
					if (x < middle - 1) {// left
						System.out.print(((x < z) ? " " : "*"));
					} else if (x > middle - 1) { // right
						System.out.print(((x > count - 1 - z) ? " " : "*"));
					} else { // middle
						System.out.print("*");
					}
				}
				if (y < middle - 1) {
					System.out.print("\r\n");
				}
			}
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}
}
