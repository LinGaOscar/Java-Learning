package com.michael.encapsulation;

public class Before {
	
	

	public static void main(String[] args) {
		
		String name = "GLE-SUV";
		double speed = 0.0;
		
		speed = speed+1;
		System.out.println("[Car name=" + name + ", speed=" + speed + "]");
		
		speed = speed * 1.2;
		speed = speed * 1.2;
		System.out.println("[Car name=" + name + ", speed=" + speed + "]");
		
		speed = speed * 0.8;
		speed = speed * 0.8;
		System.out.println("[Car name=" + name + ", speed=" + speed + "]");
		
		
		Car car1 = new Car();
		car1.setName("GLE-SUV"); // private String name
		car1.brand = "���h"; // public String brand
		car1.power = 6.5; // protected double power;
		car1.kg = 5000.0; // double kg;
		System.out.println(car1.toString() + " brand = " + car1.brand + " power = " + car1.power + " kg = " + car1.kg);
		
	}

}
