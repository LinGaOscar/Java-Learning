package michael.htmljq;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

/**
 * Servlet implementation class AjaxDataController
 */
@WebServlet("/AjaxDataController")
public class AjaxDataController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AjaxDataController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("id");

		Gson gson = new Gson();

		try {
			TimeUnit.SECONDS.sleep(10);
			
			if ("1234".equals(id)) {
				Map<String, String> resultMap = new HashMap<String, String>();
				resultMap.put("username", "Michael Chai");
				resultMap.put("userid", "116046855");
				JsonObject json = gson.toJsonTree(resultMap).getAsJsonObject();
				response.getWriter().write(gson.toJson(json));
			} else {
				response.getWriter().write("fail");
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));

		String dataJson = "";
		if (br != null) {
			dataJson = br.readLine();
			System.out.println("dataJson = " + dataJson);
		}

		Gson gson = new Gson();
		Teacher teacher = gson.fromJson(dataJson, Teacher.class);

		String result = "teacher id = " + teacher.getId() + ", teachername = " + teacher.getName();

		Map<String, String> resultMap = new HashMap<String, String>();
		resultMap.put("result", result);
		resultMap.put("msg", "true");
		JsonObject json = gson.toJsonTree(resultMap).getAsJsonObject();

		response.getWriter().write(gson.toJson(json));
	}

}
