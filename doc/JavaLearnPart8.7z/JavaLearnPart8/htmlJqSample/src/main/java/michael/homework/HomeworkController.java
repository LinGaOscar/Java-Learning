package michael.homework;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import michael.htmljq.Teacher;

/**
 * Servlet implementation class HomeworkController
 */
@WebServlet("/HomeworkController")
public class HomeworkController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HomeworkController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(request.getInputStream()));

		String dataJson = "";
		if (br != null) {
			dataJson = br.readLine();
			System.out.println("dataJson = " + dataJson);
		}

		Gson gson = new Gson();
		User loginUser = gson.fromJson(dataJson, User.class);
		JsonObject json = null;
		
		if ("a1234567".equals(loginUser.getPw())) {
			
			User user = getUserInfo(loginUser);
			
			Map<String, Object> resultMap = new HashMap<String, Object>();
			
			if (user == null) {
				resultMap.put("result", "not find user info");
				resultMap.put("msg", "false");
			}else {
				resultMap.put("result", user);
				resultMap.put("msg", "true");
			}

			json = gson.toJsonTree(resultMap).getAsJsonObject();
		}else {
			

			Map<String, Object> resultMap = new HashMap<String, Object>();
			resultMap.put("result", "not find user info");
			resultMap.put("msg", "false");
			json = gson.toJsonTree(resultMap).getAsJsonObject();
		}

		response.setContentType("text/html;charset=UTF-8"); 
		response.getWriter().write(gson.toJson(json));
	}
	
	private User getUserInfo(User loginUser) {
		if ("michael".equalsIgnoreCase(loginUser.getUserName())) {
			loginUser.setGender("男");
			loginUser.setIdNumber("A125644495");
			loginUser.setEmail("michael@gmail.com");
			return loginUser;
		}else {
			return null;
		}
	}

}
