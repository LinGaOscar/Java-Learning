import { CommandWorkspace } from '../models/interface';
export declare function insideWorkspace(): boolean;
export declare function getWorkspaceDetails(): CommandWorkspace | null;
