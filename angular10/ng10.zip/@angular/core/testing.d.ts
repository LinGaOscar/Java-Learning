/**
 * @license Angular v10.2.5
 * (c) 2010-2020 Google LLC. https://angular.io/
 * License: MIT
 */

export * from './testing/testing';
