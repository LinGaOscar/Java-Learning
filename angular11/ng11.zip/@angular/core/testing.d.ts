/**
 * @license Angular v11.0.5
 * (c) 2010-2020 Google LLC. https://angular.io/
 * License: MIT
 */

export * from './testing/testing';
