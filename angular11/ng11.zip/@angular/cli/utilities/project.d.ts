export declare function findWorkspaceFile(currentDirectory?: string): string | null;
